package com.dbs.repo.bingo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.dbs.entity.bingo.Game;
import com.dbs.entity.bingo.PrizeClaim;
import com.dbs.entity.bingo.User;
import com.dbs.model.bingo.PrizeTypes;

@Repository
public interface PrizeClaimRepository extends JpaRepository<PrizeClaim, Long> {
	PrizeClaim findByUserAndGameAndLatestNumberCalledAtThisClaimAndPrizeClaimed(User user, Game game, Integer latestNumberCalledAtThisClaim, PrizeTypes prizeClaimed);
}
