package com.dbs.service.bingo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class TableUsingJava

{

	public static void main(String args[])

	{

		Connection c = null;

		Statement stmt = null;

		try {

			Class.forName("org.sqlite.JDBC");

			c = DriverManager.getConnection("jdbc:sqlite:SqliteJavaDB.db");

			System.out.println("Database Opened...\n");

			stmt = c.createStatement();

			String sql = "CREATE TABLE Product " +

					"(p_id INTEGER PRIMARY KEY AUTOINCREMENT," +

					" p_name TEXT NOT NULL, " +

					" price REAL NOT NULL, " +

					" quantity INTEGER) ";

			stmt.executeUpdate(sql);
			sql = "INSERT INTO Product (p_name,price,quantity) " +

					"VALUES ('" + "prasad" + "'," +

					1.11 + "," + 121 + ")";

			stmt.executeUpdate(sql);

			System.out.println("Inserted Successfully!!!");

			ResultSet rs = stmt.executeQuery("SELECT * FROM Product;");

			System.out.println("ID\t Name\t\t Price\t Qty ");

			while (rs.next()) {

				Integer id = rs.getInt("p_id");

				String name = rs.getString("p_name");

				Integer quantity = rs.getInt("quantity");

				Float price = rs.getFloat("price");

				System.out.println(id + "\t " + name + " \t " + price + "\t " + quantity);

			}

			rs.close();

			stmt.close();

			c.close();

		}

		catch (Exception e) {

			System.err.println(e.getClass().getName() + ": " + e.getMessage());

			System.exit(0);

		}

		System.out.println("Table Product Created Successfully!!!");

	}

}
