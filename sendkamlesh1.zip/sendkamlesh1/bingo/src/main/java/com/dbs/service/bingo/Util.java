package com.dbs.service.bingo;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;
import java.util.Set;
import java.util.stream.Collectors;

import com.dbs.model.bingo.CardModel;
import com.dbs.model.bingo.PrizeTypes;

public class Util {

	static final int MAX = 99;
	static final int MIN = 1;

	public static CardModel getNewCard() {
		ArrayList<Integer> lst = new ArrayList<>();
		while (lst.size() < 15) {
			Random rand = new Random(System.currentTimeMillis());
			int num = rand.nextInt(MAX - MIN + 1) + MIN;
			if (lst.contains(num)) {
				continue;
			}
			lst.add(num);
		}
		CardModel card = new CardModel();
		card.setRow1(lst.subList(0, 4).stream().sorted().collect(Collectors.toSet()));
		card.setRow2(lst.subList(5, 9).stream().sorted().collect(Collectors.toSet()));
		card.setRow3(lst.subList(10, 14).stream().sorted().collect(Collectors.toSet()));
		return card;
	}

	public static Integer getNewRandomNumber(Set<Integer> alreadyCalledNumbers) {
		boolean isFound = false;
		int num = 0;
		while (!isFound) {
			Random rand = new Random(System.currentTimeMillis());
			num = rand.nextInt(MAX - MIN + 1) + MIN;
			if (alreadyCalledNumbers.contains(num)) {
				continue;
			} else {
				isFound = true;
			}
		}
		return num;
	}

	public static boolean isPrizeClaimValid(PrizeTypes prizeClaimed, com.dbs.entity.bingo.Card dbCard,
			Set<Integer> numsAlreadyCalled) {
		boolean isClaimValid = false;
		switch (prizeClaimed) {
		case BINGO:
			if (numsAlreadyCalled.containsAll(dbCard.getRow1()) && numsAlreadyCalled.containsAll(dbCard.getRow2())
					&& numsAlreadyCalled.containsAll(dbCard.getRow3())) {
				isClaimValid = true;
			}
			break;
		case FIRST_5:
			int countFound = 0;
			for (Iterator<Integer> it = numsAlreadyCalled.iterator(); it.hasNext() && countFound < 5;) {
				Integer num = it.next();
				if (dbCard.getRow1().contains(num)
						|| dbCard.getRow2().contains(num)
						|| dbCard.getRow3().contains(num)) {
					countFound++;
				}
			}
			if (countFound == 5) {
				isClaimValid = true;
			}
			break;
		case ROW1:
			if (numsAlreadyCalled.containsAll(dbCard.getRow1())) {
				isClaimValid = true;
			}
			break;
		case ROW2:
			if (numsAlreadyCalled.containsAll(dbCard.getRow2())) {
				isClaimValid = true;
			}
			break;
		case ROW3:
			if (numsAlreadyCalled.containsAll(dbCard.getRow3())) {
				isClaimValid = true;
			}
			break;
		}
		return isClaimValid;
	}
}
