package com.dbs.entity.bingo;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import com.dbs.model.bingo.GameStatusTypes;

@Entity
public class Game {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	@Column
	private GameStatusTypes currentState;
	@OneToMany(fetch = FetchType.EAGER)
	@JoinColumn(name="user_id")
	private Set<User> users;
	@OneToOne(fetch = FetchType.EAGER)
	@JoinColumn(name="game_playground_id")
	private GamePlayground gamePlayground;
	public GamePlayground getGamePlayground() {
		return gamePlayground;
	}
	public void setGamePlayground(GamePlayground gamePlayground) {
		this.gamePlayground = gamePlayground;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public GameStatusTypes getCurrentState() {
		return currentState;
	}
	public void setCurrentState(GameStatusTypes currentState) {
		this.currentState = currentState;
	}
	public Set<User> getUsers() {
		return users;
	}
	public void setUsers(Set<User> users) {
		this.users = users;
	}

}
