package com.dbs.model.bingo;

import java.util.Set;

public class GameNumber {
	private int latestNumber;
	private Set<Integer> numbersAlreadyCalled;

	public GameNumber(int latestNumber, Set<Integer> numbersAlreadyCalled) {
		super();
		this.latestNumber = latestNumber;
		this.numbersAlreadyCalled = numbersAlreadyCalled;
	}

	public int getLatestNumber() {
		return latestNumber;
	}

	public void setLatestNumber(int latestNumber) {
		this.latestNumber = latestNumber;
	}

	public Set<Integer> getNumbersAlreadyCalled() {
		return numbersAlreadyCalled;
	}

	public void setNumbersAlreadyCalled(Set<Integer> numbersAlreadyCalled) {
		this.numbersAlreadyCalled = numbersAlreadyCalled;
	}
	
}
