package com.dbs.service.bingo;

import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dbs.entity.bingo.User;
import com.dbs.repo.bingo.UserRepository;

@Service
public class UserService {

	@Autowired
	private UserRepository userRepository;

	public User createUser(String name) {
		User user = userRepository.findByName(name);
		if (user == null) {
			User newUser = new User();
			newUser.setName(name);
			user = userRepository.save(newUser);
		}
		return user;
	}

	public List<User> createUsers() {
		createUser("John Doe");
		createUser("Willian Cost");
		return userRepository.findAll();
	}

	public List<User> getAllUsers() {
		List<User> usrs = userRepository.findAll();
		for (Iterator<User> it2 = usrs.iterator(); it2.hasNext();) {
			User usr = it2.next();
			usr.setCurrentGameCard(null);
		}
		return usrs;
	}

	
}
