package com.dbs.entity.bingo;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import com.dbs.model.bingo.PrizeTypes;

@Entity
public class GamePlayground {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;

	//@OneToOne
	//@JoinColumn(name="game_id")
	//private Game game;
	@Column
	@ElementCollection(targetClass=Integer.class)
	private Set<Integer> numbersAlreadyCalled;
	@Column
	private Integer latestNum;
	@Column
	@ElementCollection(targetClass=PrizeTypes.class)
	private Set<PrizeTypes> prizesAlreadyClaimed;
	@Column
	@ElementCollection(targetClass=PrizeTypes.class)
	private Set<PrizeTypes> prizesClaimedInCurrentNumber;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	/*
	public Game getGame() {
		return game;
	}
	public void setGame(Game game) {
		this.game = game;
	}
	*/
	public Set<Integer> getNumbersAlreadyCalled() {
		return numbersAlreadyCalled;
	}
	public void setNumbersAlreadyCalled(Set<Integer> numbersAlreadyCalled) {
		this.numbersAlreadyCalled = numbersAlreadyCalled;
	}
	public Integer getLatestNum() {
		return latestNum;
	}
	public void setLatestNum(Integer latestNum) {
		this.latestNum = latestNum;
	}
	public Set<PrizeTypes> getPrizesAlreadyClaimed() {
		return prizesAlreadyClaimed;
	}
	public void setPrizesAlreadyClaimed(Set<PrizeTypes> prizesAlreadyClaimed) {
		this.prizesAlreadyClaimed = prizesAlreadyClaimed;
	}
	public Set<PrizeTypes> getPrizesClaimedInCurrentNumber() {
		return prizesClaimedInCurrentNumber;
	}
	public void setPrizesClaimedInCurrentNumber(Set<PrizeTypes> prizesClaimedInCurrentNumber) {
		this.prizesClaimedInCurrentNumber = prizesClaimedInCurrentNumber;
	}
	
}
