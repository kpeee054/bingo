package com.dbs.entity.bingo;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import com.dbs.model.bingo.PrizeTypes;

@Entity
public class PrizeWin {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;

	@OneToOne
	@JoinColumn
	private Game game;
	
	@OneToMany
	@JoinColumn(name="user_id")
	private Set<User> users;
	
	@Column
	private PrizeTypes prizeWon;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Game getGame() {
		return game;
	}

	public void setGame(Game game) {
		this.game = game;
	}

	public Set<User> getUsers() {
		return users;
	}

	public void setUsers(Set<User> users) {
		this.users = users;
	}

	public PrizeTypes getPrizeWon() {
		return prizeWon;
	}

	public void setPrizeWon(PrizeTypes prizeWon) {
		this.prizeWon = prizeWon;
	}

}
