package com.dbs.model.bingo;

import java.util.Set;

import com.dbs.entity.bingo.PrizeWin;

public class LatestData {
	private int latestNumber;
	private Set<Integer> numbersAlreadyCalled;
	private Set<PrizeWin> prizeWins;

	public LatestData(int latestNumber, Set<Integer> numbersAlreadyCalled, Set<PrizeWin> prizeWins) {
		super();
		this.latestNumber = latestNumber;
		this.numbersAlreadyCalled = numbersAlreadyCalled;
		this.prizeWins = prizeWins;
	}

	public int getLatestNumber() {
		return latestNumber;
	}

	public void setLatestNumber(int latestNumber) {
		this.latestNumber = latestNumber;
	}

	public Set<Integer> getNumbersAlreadyCalled() {
		return numbersAlreadyCalled;
	}

	public void setNumbersAlreadyCalled(Set<Integer> numbersAlreadyCalled) {
		this.numbersAlreadyCalled = numbersAlreadyCalled;
	}

	public Set<PrizeWin> getPrizeWins() {
		return prizeWins;
	}

	public void setPrizeWins(Set<PrizeWin> prizeWins) {
		this.prizeWins = prizeWins;
	}
	
}
