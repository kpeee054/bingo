import { SortByTimePipe } from './sort-by-time.pipe';

describe('SortByTimePipe', () => {
  it('create an instance', () => {
    const pipe = new SortByTimePipe();
    expect(pipe).toBeTruthy();
  });
});
