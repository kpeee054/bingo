import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';

@Component({
  selector: 'app-userdashboard',
  templateUrl: './userdashboard.component.html',
  styleUrls: ['./userdashboard.component.css']
})
export class UserdashboardComponent implements OnInit {
  // dummy data for now
 // userData: any = { 'row1': [45, 54, 67, 8, 27], 'row2': [34, 65, 67, 8, 33], 'row3': [40, 14, 61, 83, 77] };
  newcardResponse: any;
  value = true;
  existCardResponse: any;
  newNumberResponse: any;
  joingameResponse: any;
  row1Prize: any;
  row2Prize: any;
  row3Prize: any;
  loggedInUser: any;
  showcard = false;
  userId: any;
  constructor(private http: HttpClient) { }

  ngOnInit() {
    this.loggedInUser = JSON.parse(localStorage.getItem('userObject'));
    this.userId = JSON.parse(localStorage.getItem('userId'));
  }
  // To join game
  joinGame() {
    this.http.get<any>('http://localhost:8080/' + this.userId + '/joinGame').subscribe(
      data => {
        this.joingameResponse = data,
          console.log('joingameResponse===>', this.joingameResponse);
      },
      error => console.error('There was an error!', error)
    );
    this.newCard();
    this.showcard = true;
  }

  // Get New Card API
  newCard() {
    this.http.get<any>('http://localhost:8080/' + this.userId + '/newCard').subscribe(
      data => {
      this.newcardResponse = data,
        console.log('newcardResponse===>', this.newcardResponse);
      },
      error => console.error('There was an error!', error)
    );

  }
  // Retrieve existing card API
  retrievecard() {
    this.http.get<any>('http://localhost:8080/' + this.userId + '/card').subscribe(
      data => this.existCardResponse = data,
      error => console.error('There was an error!', error)
    );
    console.log('existCardResponse===>', this.existCardResponse);
  }
  // Get New Random Number API
  newNumber() {
    this.http.get<any>('http://localhost:8080/play/newNumber').subscribe(
      data => this.newNumberResponse = data,
      error => console.error('There was an error!', error)
    );

  }
  myClick(item) {
    // document.getElementById('cell').disabled = this.value;
    // this.value = false;
    console.log('cell value', item);
  }

  myRow1Prize() {
    const params = new HttpParams().set('prize', 'row1');
    this.http.get<any>('http://localhost:8080/' + this.userId + '/prize/claim', { params: params }).subscribe(
      data => {
      this.row1Prize = data,
        console.log('row1Prize===>', this.row1Prize);
      },
      error => console.error('There was an error!', error)
    );
  }

  myRow2Prize() {
    const params = new HttpParams().set('prize', 'row2');
    this.http.get<any>('http://localhost:8080/' + this.userId + '/prize/claim', { params: params }).subscribe(
      data => {
      this.row2Prize = data,
        console.log('row2Prize===>', this.row2Prize);
      },
      error => console.error('There was an error!', error)
    );
  }

  myRow3Prize() {
    const params = new HttpParams().set('prize', 'row2');
    this.http.get<any>('http://localhost:8080/' + this.userId + '/prize/claim', { params: params }).subscribe(
      data => {
      this.row3Prize = data,
        console.log('row3Prize===>', this.row3Prize);
      },
      error => console.error('There was an error!', error)
    );
  }
}
