import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Router } from '@angular/router';


// export interface User {
//   id: number;
//   name: string;
//   currentGameCard: object
//   confirmed: object

// }



@Component({
  selector: 'app-loginuser',
  templateUrl: './loginuser.component.html',
  styleUrls: ['./loginuser.component.css']
})
export class LoginuserComponent implements OnInit {

  //  USERS: User[] = [
  //   { id: 11, name: 'Kamlesh ' },
  //   { id: 12, name: 'Prasad ' },
  //   { id: 13, name: 'Janaki' },
  //   { id: 14, name: 'Gaurav' },
  //   { id: 15, name: 'Joel' },
  //   { id: 16, name: 'Deelip' },
  //   { id: 17, name: 'Kondala' }
  // ];

  USERS: any[];
  loginuserResponse: any;
  logoutUserrespnse: any;

  selectedUser: any;

  ngOnInit(): void {
    this.getAllUsers();
  }
  constructor(private http: HttpClient, private router: Router) { }

  // get all users
  getAllUsers() {
    this.http.get<any>('http://localhost:8080/getAllUsers').subscribe(
      data => this.USERS = data,
      error => console.error('There was an error!', error)
    );
  }
  // login user
  loginUser(currentuserdata) {
    const params = new HttpParams().set('name', currentuserdata.id);
    this.http.get<any>('http://localhost:8080/login', { params: params }).subscribe(
      data => {
        this.loginuserResponse = data,
          localStorage.setItem('userId', JSON.stringify(this.loginuserResponse));
      },
      error => console.error('There was an error!', error)
    );
    console.log('Logged in UserId==>', currentuserdata);
    localStorage.setItem('userObject', JSON.stringify(currentuserdata));
    // navigate to user page
    this.router.navigate(['/user']);
    // console.log('loginuserResponse===>', this.loginuserResponse);

  }
  // logout user
  logOutUser(userId) {
    this.http.get<any>('http://localhost:8080/' + userId + '/logout').subscribe(
      data => this.logoutUserrespnse = data,
      error => console.error('There was an error!', error)
    );
    console.log('logoutUserrespnse===>', this.logoutUserrespnse);

  }
  onSelect(user: any): void {
    this.selectedUser = user;
  }


}
