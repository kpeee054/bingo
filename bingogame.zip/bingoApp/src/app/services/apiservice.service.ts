import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ApiserviceService {
  private BINGO_API_SERVER = 'http://localhost:8080';
  constructor(private httpClient: HttpClient) { }

  public createUsers() {
    return this.httpClient.get(this.BINGO_API_SERVER + '/createUsers');
  }

}
