import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import * as Stomp from 'stompjs';
import * as SockJS from 'sockjs-client';
import { ApiserviceService } from '../services/apiservice.service';
import { GameService } from '../services/game.service';

@Component({
  selector: 'app-admindashboard',
  templateUrl: './admindashboard.component.html',
  styleUrls: ['./admindashboard.component.css']
})
export class AdmindashboardComponent implements OnInit {
  createdUsers: any;
  startNewGameresponse: any;
  getStartedGameResponse: any;
  latestNumber: string;
  ws: any;


  constructor(private http: HttpClient, private apiservice: ApiserviceService, private gameService: GameService, private router: Router) {

  }

  ngOnInit() {

  }

  createNewGame() {
    const newGame = this.gameService.createGame();
    this.router.navigate(['/games', newGame.id]);
  }

  createUsers(): void {
    this.apiservice.createUsers().subscribe((data: any) => {
      console.log('logging created users==>', data);
      this.createdUsers = data;
    });
    // this.http.get<any>('http://localhost:8080/createUsers').subscribe(
    //   data => this.createdUsers = JSON.parse(data),
    //   error => console.error('There was an error!', error)
    // );
    console.log('createdUsers===>', this.createdUsers);

  }

  startNewGame() {
    this.http.get<any>('http://localhost:8080/startNewGame').subscribe(
      data => {
        console.log('startNewGameresponse===>', data);
        this.startNewGameresponse = data;
      },
      error => console.error('There was an error!', error)
    );
    console.log('startNewGameresponse===>', this.startNewGameresponse);

  }

  getStartedGame() {
    this.http.get<any>('http://localhost:8080/getStartedGame').subscribe(
      data => this.getStartedGameResponse = data,
      error => console.error('There was an error!', error)
    );
    console.log('getStartedGameResponse===>', this.getStartedGameResponse);

  }

  connect() {
    //connect to stomp where stomp endpoint is exposed
    //let ws = new SockJS(http://localhost:8080/greeting);
    let socket = new WebSocket("ws://localhost:8080/start-websocket");
    this.ws = Stomp.over(socket);
    let that = this;
    this.ws.connect({}, function (frame) {
      that.ws.subscribe("/errors", function (message) {
        alert("Error " + message.body);
      });
      that.ws.subscribe("/topic/ws/newNumber", function (message) {
        console.log('[][]' + message.body);
        //that.showGreeting(message.body);
      });
      //that.disabled = true;
    }, function (error) {
      alert("STOMP error " + error);
    });
  }


  newNumber() {
    //this.ws.send("/app/ws/play/newNumber", {}, {});
    this.http.get<any>('http://localhost:8080/play/newNumber').subscribe(
      data => this.latestNumber = data.latestNumber,
      error => console.error('Error', error)
    );
    console.log('newNumber Response===>', this.latestNumber);
  }
}
