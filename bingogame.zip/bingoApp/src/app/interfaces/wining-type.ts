export interface WiningType {
    numbers: string,
    name: string
}
