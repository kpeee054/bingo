import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Game } from './../interfaces/game';
import { Router } from '@angular/router';
import * as Stomp from 'stompjs';
import * as SockJS from 'sockjs-client';

@Component({
  selector: '[app-game]',
  templateUrl: './game.component.html',
  styleUrls: ['./game.component.css']
})
export class GameComponent implements OnInit {

  @Input() game: Game;
  @Input() isPlay: boolean;
  @Output() updateNumber = new EventEmitter();
  @Output() completeGame = new EventEmitter();
  ws: any;
  myLastNumber: number;
  constructor(private router: Router) { }

  ngOnInit() {
    this.connect();
    console.log('()()()()()');
  }

  startGame(event) {
    event.stopPropagation();
    this.router.navigate(['/games', this.game.id]);
  }

  onUpdateNumber() {
    this.updateNumber.emit();
  }

  onCompleteGame() {
    this.completeGame.emit();
  }

  setLastNumber(num: number) {
    this.myLastNumber = num;
    this.game.lastNumber = num;
    console.log('======>>' + this.myLastNumber);
  }
  connect() {
    //connect to stomp where stomp endpoint is exposed
    //let ws = new SockJS(http://localhost:8080/greeting);
    let socket = new WebSocket("ws://localhost:8080/start-websocket");
    this.ws = Stomp.over(socket);
    let that = this;
    this.ws.connect({}, function(frame) {
      that.ws.subscribe("/errors", function(message) {
        alert("Error " + message.body);
      });
      that.ws.subscribe("/topic/ws/newNumber", function(message) {
        console.log('[*]' + message.body);
        console.log('[**]' + JSON.parse(message.body).latestNumber);
        that.setLastNumber(JSON.parse(message.body).latestNumber);
        //that.showGreeting(message.body);
      });
      //that.disabled = true;
    }, function(error) {
      alert("STOMP error " + error);
    });
}

}
