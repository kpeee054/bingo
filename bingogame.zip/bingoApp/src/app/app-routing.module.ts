import { NgModule } from '@angular/core';
import { RouterModule, Routes} from '@angular/router';


import { GamesComponent } from './games/games.component';
import { PlayComponent } from './play/play.component';
import { RulesComponent } from './rules/rules.component';
import {UserdashboardComponent} from './userdashboard/userdashboard.component';
import {AdmindashboardComponent} from './admindashboard/admindashboard.component';
import { LoginuserComponent } from './loginuser/loginuser.component';

const routes: Routes = [
  // {path: '', redirectTo: '/user', pathMatch: 'full'},
  {path: 'games', component: GamesComponent},
  {path: 'games/:id', component: PlayComponent},
  {path: 'rules', component: RulesComponent},
  {path: 'user', component: UserdashboardComponent},
  {path: '', component: LoginuserComponent},
  {path: 'admin', component: AdmindashboardComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {enableTracing: false})],
  exports: [RouterModule],
  declarations: []
})
export class AppRoutingModule { }
