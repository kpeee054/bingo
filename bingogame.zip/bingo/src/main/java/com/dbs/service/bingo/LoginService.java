package com.dbs.service.bingo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dbs.entity.bingo.Login;
import com.dbs.entity.bingo.User;
import com.dbs.model.bingo.ReturnStatus;
import com.dbs.model.bingo.UserLoginTypes;
import com.dbs.repo.bingo.LoginRepository;
import com.dbs.repo.bingo.UserRepository;

@Service
public class LoginService {

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private LoginRepository loginRepository;
	
	public Long login(String name) {
		User user = userRepository.findByName(name);
		if (user==null) {
			throw new RuntimeException("No user found with name: \"" + name + "\"");
		}
		Login login = new Login();
		login.setUser(user);
		login.setUserLogin(UserLoginTypes.LOGGED_IN);
		loginRepository.save(login);
		return user.getId();
	}

	public ReturnStatus logout(String userId) {
		User user = userRepository.findById(Long.valueOf(userId)).get();
		if (user==null) {
			throw new RuntimeException("No user found with user-id: \"" + userId + "\"");
		}
		Login login = new Login();
		login.setUser(user);
		login.setUserLogin(UserLoginTypes.LOGGED_OUT);
		loginRepository.save(login);
		return new ReturnStatus("0", UserLoginTypes.LOGGED_OUT.toString());
	}
}
