package com.dbs.service.bingo;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dbs.entity.bingo.Card;
import com.dbs.entity.bingo.Game;
import com.dbs.entity.bingo.GamePlayground;
import com.dbs.entity.bingo.PrizeClaim;
import com.dbs.entity.bingo.PrizeWin;
import com.dbs.entity.bingo.User;
import com.dbs.model.bingo.CardModel;
import com.dbs.model.bingo.GameNumber;
import com.dbs.model.bingo.GameStatusTypes;
import com.dbs.model.bingo.PrizeClaimStatusTypes;
import com.dbs.model.bingo.PrizeTypes;
import com.dbs.model.bingo.ReturnStatus;
import com.dbs.repo.bingo.CardRepository;
import com.dbs.repo.bingo.GamePlaygroundRepository;
import com.dbs.repo.bingo.GameRepository;
import com.dbs.repo.bingo.PrizeClaimRepository;
import com.dbs.repo.bingo.PrizeWinRepository;
import com.dbs.repo.bingo.UserRepository;

@Service
public class GameService {

	@Autowired
	private GameRepository gameRepository;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private CardRepository cardRepository;

	@Autowired
	private GamePlaygroundRepository gamePlaygroundRepository;

	@Autowired
	private PrizeClaimRepository prizeClaimRepository;

	@Autowired
	private PrizeWinRepository prizeWinRepository;

	@Autowired
	private EntityManager em;

	public Game startGame() {
		Game game = gameRepository.findByCurrentState(GameStatusTypes.STARTED);
		if (game == null) {
			Game newGame = new Game();
			newGame.setCurrentState(GameStatusTypes.STARTED);
			GamePlayground gamePlayground = new GamePlayground();
			gamePlaygroundRepository.save(gamePlayground);
			newGame.setGamePlayground(gamePlayground);
			game = gameRepository.save(newGame);
			// gamePlayground.setGame(game);
			// gamePlaygroundRepository.save(gamePlayground);
		}
		Set<User> usrs = game.getUsers();
		if (usrs != null) {
			for (Iterator<User> it = usrs.iterator(); it.hasNext();) {
				User usr = it.next();
				usr.setCurrentGameCard(null);
			}
		}
		return game;
	}

	public Game fetchStartedGame() {
		Game game = gameRepository.findByCurrentState(GameStatusTypes.STARTED);
		if (game == null) {
			throw new RuntimeException("Game not started.");
		}
		Set<User> usrs = game.getUsers();
		if (usrs != null) {
			for (Iterator<User> it = usrs.iterator(); it.hasNext();) {
				User usr = it.next();
				usr.setCurrentGameCard(null);
			}
		}
		return game;
	}

	public Game joinGame(String userId) {
		Game game = gameRepository.findByCurrentState(GameStatusTypes.STARTED);
		if (game == null) {
			throw new RuntimeException("Game not started.");
		}
		if (game.getGamePlayground().getNumbersAlreadyCalled().size() >= 4) {
			throw new RuntimeException("You cannot join game now. Game is past 5 numbers.");
		}
		User user = userRepository.findById(Long.valueOf(userId)).get();
		Set<User> currentUsers = game.getUsers();
		Game uGame = null;
		if (currentUsers.contains(user)) {
			uGame = game;
		} else {
			currentUsers.add(user);
			game.setUsers(currentUsers);
			uGame = gameRepository.save(game);
		}
		Set<User> usrs = uGame.getUsers();
		if (usrs != null) {
			for (Iterator<User> it = usrs.iterator(); it.hasNext();) {
				User usr = it.next();
				usr.setCurrentGameCard(null);
			}
		}
		return uGame;
	}

	public Card getNewCard(String userId) {
		Game game = gameRepository.findByCurrentState(GameStatusTypes.STARTED);
		if (game == null) {
			throw new RuntimeException("Game not started.");
		}
		User user = userRepository.findById(Long.valueOf(userId)).get();
		if (!game.getUsers().contains(user)) {
			throw new RuntimeException("You need to join the game.");
		}
		if (user.getConfirmed() != null && user.getConfirmed() == true) {
			throw new RuntimeException("You cannot change after card confirmation.");
		}
		CardModel newCard = Util.getNewCard();
		Card dbCard = new Card();
		dbCard.setGame(game);
		dbCard.setUser(user);
		dbCard.setRow1(newCard.getRow1());
		dbCard.setRow2(newCard.getRow2());
		dbCard.setRow3(newCard.getRow3());
		cardRepository.save(dbCard);
		// em.detach(dbCard);
		user.setCurrentGameCard(dbCard);
		userRepository.save(user);
		dbCard.getUser().setCurrentGameCard(null);
		dbCard.setGame(null);
		return dbCard;
	}

	public Card getExistingCard(String userId) {
		Game game = gameRepository.findByCurrentState(GameStatusTypes.STARTED);
		if (game == null) {
			throw new RuntimeException("Game not started.");
		}
		User user = userRepository.findById(Long.valueOf(userId)).get();
		if (!game.getUsers().contains(user)) {
			throw new RuntimeException("You need to join the game.");
		}
		Card dbCard = user.getCurrentGameCard();
		if (dbCard == null) {
			throw new RuntimeException("Please generate a card.");
		}
		dbCard.getUser().setCurrentGameCard(null);
		dbCard.setGame(null);
		return dbCard;
	}

	public GameNumber getNewNumber() {
		Game game = gameRepository.findByCurrentState(GameStatusTypes.STARTED);
		if (game == null) {
			throw new RuntimeException("Game not started.");
		}
		GamePlayground gamePlayground = game.getGamePlayground();
		if (gamePlayground.getPrizesClaimedInCurrentNumber().contains(PrizeTypes.BINGO)) {
			throw new RuntimeException("BINGO won!");
		}
		if (gamePlayground.getNumbersAlreadyCalled().size() == 99) {
			throw new RuntimeException("All Numbers (1-99) called!");
		}
		// book keeping - add current prizes (from previous number) to already claimed
		// prizes
		// before this new number is announced. Then, clear current prizes.
		gamePlayground.getPrizesAlreadyClaimed().addAll(gamePlayground.getPrizesClaimedInCurrentNumber());
		gamePlayground.getPrizesClaimedInCurrentNumber().clear();
		Set<Integer> numAlreadyCalled = gamePlayground.getNumbersAlreadyCalled();
		int newNumber = Util.getNewRandomNumber(numAlreadyCalled);
		numAlreadyCalled.add(newNumber);
		gamePlayground.setLatestNum(newNumber);
		gamePlaygroundRepository.save(gamePlayground);
		return new GameNumber(newNumber);
	}

	public PrizeClaim prizeClaim(String userId, String prizeName) {
		try {
			PrizeTypes.valueOf(prizeName.toUpperCase());
		} catch (Exception ex) {
			throw new RuntimeException("Unknown Prize Claimed.");
		}
		Game game = gameRepository.findByCurrentState(GameStatusTypes.STARTED);
		if (game == null) {
			throw new RuntimeException("Game not started.");
		}
		if (game.getGamePlayground().getPrizesAlreadyClaimed().contains(PrizeTypes.valueOf(prizeName.toUpperCase()))) {
			throw new RuntimeException("Prize already won.");
		}
		User user = userRepository.findById(Long.valueOf(userId)).get();
		PrizeClaim existingPrizeClaim = prizeClaimRepository
				.findByUserAndGameAndLatestNumberCalledAtThisClaimAndPrizeClaimed(user, game,
						game.getGamePlayground().getLatestNum(), PrizeTypes.valueOf(prizeName.toUpperCase()));
		if (existingPrizeClaim != null) {
			throw new RuntimeException("You attempted to claim this Prize Already.");
		}
		Set<Integer> numsAlreadyCalled = game.getGamePlayground().getNumbersAlreadyCalled();
		Card dbCard = user.getCurrentGameCard();
		boolean isValidClaim = Util.isPrizeClaimValid(PrizeTypes.valueOf(prizeName.toUpperCase()), dbCard,
				numsAlreadyCalled);
		PrizeClaim prizeClaim = new PrizeClaim();
		prizeClaim.setGame(game);
		prizeClaim.setUser(user);
		prizeClaim.setPrizeClaimed(PrizeTypes.valueOf(prizeName.toUpperCase()));
		prizeClaim.setLatestNumberCalledAtThisClaim(game.getGamePlayground().getLatestNum());
		if (isValidClaim) {
			if (game.getGamePlayground().getPrizesAlreadyClaimed()
					.contains(PrizeTypes.valueOf(prizeName.toUpperCase()))) {
				prizeClaim.setStatus(PrizeClaimStatusTypes.VALID_BUT_ALREADY_CLAIMED);
			} else {
				prizeClaim.setStatus(PrizeClaimStatusTypes.APPROVED);
				PrizeWin prizeWin = new PrizeWin();
				prizeWin.setGame(game);
				Set<User> users = prizeWin.getUsers();
				if (users == null) {
					users = new HashSet<>();
				}
				users.add(user);
				prizeWin.setUsers(users);
				prizeWin.setPrizeWon(PrizeTypes.valueOf(prizeName.toUpperCase()));
				prizeWinRepository.save(prizeWin);
				// update playground
				Set<PrizeTypes> prizeAlreadyApprovedInCurrentNumber = game.getGamePlayground()
						.getPrizesClaimedInCurrentNumber();
				if (prizeAlreadyApprovedInCurrentNumber == null) {
					prizeAlreadyApprovedInCurrentNumber = new HashSet<>();
				}
				prizeAlreadyApprovedInCurrentNumber.add(PrizeTypes.valueOf(prizeName.toUpperCase()));
				game.getGamePlayground().setPrizesClaimedInCurrentNumber(prizeAlreadyApprovedInCurrentNumber);
				gamePlaygroundRepository.save(game.getGamePlayground());
			}
		} else {
			prizeClaim.setStatus(PrizeClaimStatusTypes.INVALID);
		}
		prizeClaimRepository.save(prizeClaim);
		prizeClaim.setUser(null);
		prizeClaim.setGame(null);
		return prizeClaim;
	}

	public GameNumber getLatestNumber() {
		Game game = gameRepository.findByCurrentState(GameStatusTypes.STARTED);
		if (game == null) {
			throw new RuntimeException("Game not started.");
		}
		return new GameNumber(game.getGamePlayground().getLatestNum());
	}

	public ReturnStatus endGame() {
		Game game = gameRepository.findByCurrentState(GameStatusTypes.STARTED);
		if (game == null) {
			throw new RuntimeException("Game not started.");
		}
		game.setCurrentState(GameStatusTypes.ENDED);
		gameRepository.save(game);
		return new ReturnStatus("0", GameStatusTypes.ENDED.toString());
	}

	public ReturnStatus abortGame() {
		Game game = gameRepository.findByCurrentState(GameStatusTypes.STARTED);
		if (game == null) {
			throw new RuntimeException("Game not started.");
		}
		game.setCurrentState(GameStatusTypes.ABORTED);
		gameRepository.save(game);
		return new ReturnStatus("0", GameStatusTypes.ABORTED.toString());
	}

	public Set<PrizeWin> getPrizeWins() {
		Game game = gameRepository.findByCurrentState(GameStatusTypes.STARTED);
		if (game == null) {
			throw new RuntimeException("Game not started.");
		}
		Set<PrizeWin> prizeWinSet = prizeWinRepository.findByGame(game);
		if (prizeWinSet != null) {
			for (Iterator<PrizeWin> it = prizeWinSet.iterator(); it.hasNext();) {
				PrizeWin pw = it.next();
				pw.getGame().setUsers(null);
				Set<User> usrs = pw.getUsers();
				if (usrs != null) {
					for (Iterator<User> it2 = usrs.iterator(); it2.hasNext();) {
						User usr = it2.next();
						usr.setCurrentGameCard(null);
					}
				}
			}
		}
		return prizeWinSet;
	}

	public Card confirmCard(String userId) {
		Game game = gameRepository.findByCurrentState(GameStatusTypes.STARTED);
		if (game == null) {
			throw new RuntimeException("Game not started.");
		}
		User user = userRepository.findById(Long.valueOf(userId)).get();
		if (!game.getUsers().contains(user)) {
			throw new RuntimeException("You need to join the game.");
		}
		Card dbCard = user.getCurrentGameCard();
		if (dbCard == null) {
			throw new RuntimeException("Please generate a card first.");
		}
		user.setConfirmed(true);
		userRepository.save(user);
		dbCard.getUser().setCurrentGameCard(null);
		dbCard.setGame(null);
		return dbCard;
	}
}
