package com.dbs.model.bingo;

public enum PrizeClaimStatusTypes {
	APPROVED, VALID_BUT_ALREADY_CLAIMED, INVALID
}
