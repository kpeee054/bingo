package com.dbs.model.bingo;

import java.util.Set;

public class GameModel {
	private Long id;
	private GameStatusTypes currentState;
	private Set<UserModel> users;
	private GamePlaygroundModel gamePlaygroundModel;
	
	public GameModel() {
		super();
		this.gamePlaygroundModel = new GamePlaygroundModel();
	}
	public GamePlaygroundModel getGamePlaygroundModel() {
		return gamePlaygroundModel;
	}
	public void setGamePlaygroundModel(GamePlaygroundModel gamePlaygroundModel) {
		this.gamePlaygroundModel = gamePlaygroundModel;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public GameStatusTypes getCurrentState() {
		return currentState;
	}
	public void setCurrentState(GameStatusTypes currentState) {
		this.currentState = currentState;
	}
	public Set<UserModel> getUsers() {
		return users;
	}
	public void setUsers(Set<UserModel> users) {
		this.users = users;
	}
}
