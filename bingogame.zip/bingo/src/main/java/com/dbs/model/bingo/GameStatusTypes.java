package com.dbs.model.bingo;

public enum GameStatusTypes {
	STARTED, ENDED, ABORTED
}
