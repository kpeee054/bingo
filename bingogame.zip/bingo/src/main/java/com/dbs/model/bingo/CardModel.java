package com.dbs.model.bingo;

import java.util.Set;

public class CardModel {
	private Long id;
	private Set<Integer> row1;
	private Set<Integer> row2;
	private Set<Integer> row3;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Set<Integer> getRow1() {
		return row1;
	}
	public void setRow1(Set<Integer> row1) {
		this.row1 = row1;
	}
	public Set<Integer> getRow2() {
		return row2;
	}
	public void setRow2(Set<Integer> row2) {
		this.row2 = row2;
	}
	public Set<Integer> getRow3() {
		return row3;
	}
	public void setRow3(Set<Integer> row3) {
		this.row3 = row3;
	}
	
}
