package com.dbs.model.bingo;

public enum PrizeTypes {
	BINGO, FIRST_5, ROW1, ROW2, ROW3
}
