package com.dbs.model.bingo;

public class GameNumber {
	private int latestNumber;

	public GameNumber(int latestNumber) {
		super();
		this.latestNumber = latestNumber;
	}

	public int getLatestNumber() {
		return latestNumber;
	}

	public void setLatestNumber(int latestNumber) {
		this.latestNumber = latestNumber;
	}
	
}
