package com.dbs.model.bingo;

import java.util.Set;

public class GamePlaygroundModel {
	private Long id;
	private Set<Integer> numbersAlreadyCalled;
	private Integer latestNum;
	private Set<PrizeTypes> prizesAlreadyClaimed;
	private Set<PrizeTypes> prizesClaimedInCurrentNumber;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	/*
	public Game getGame() {
		return game;
	}
	public void setGame(Game game) {
		this.game = game;
	}
	*/
	public Set<Integer> getNumbersAlreadyCalled() {
		return numbersAlreadyCalled;
	}
	public void setNumbersAlreadyCalled(Set<Integer> numbersAlreadyCalled) {
		this.numbersAlreadyCalled = numbersAlreadyCalled;
	}
	public Integer getLatestNum() {
		return latestNum;
	}
	public void setLatestNum(Integer latestNum) {
		this.latestNum = latestNum;
	}
	public Set<PrizeTypes> getPrizesAlreadyClaimed() {
		return prizesAlreadyClaimed;
	}
	public void setPrizesAlreadyClaimed(Set<PrizeTypes> prizesAlreadyClaimed) {
		this.prizesAlreadyClaimed = prizesAlreadyClaimed;
	}
	public Set<PrizeTypes> getPrizesClaimedInCurrentNumber() {
		return prizesClaimedInCurrentNumber;
	}
	public void setPrizesClaimedInCurrentNumber(Set<PrizeTypes> prizesClaimedInCurrentNumber) {
		this.prizesClaimedInCurrentNumber = prizesClaimedInCurrentNumber;
	}
	
}
