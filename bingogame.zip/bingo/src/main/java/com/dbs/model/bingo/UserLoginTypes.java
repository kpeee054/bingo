package com.dbs.model.bingo;

public enum UserLoginTypes {
	LOGGED_IN, LOGGED_OUT
}
