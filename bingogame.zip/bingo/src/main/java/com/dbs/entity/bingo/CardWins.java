package com.dbs.entity.bingo;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import com.dbs.model.bingo.PrizeTypes;

@Entity
public class CardWins {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	@OneToOne
	@JoinColumn(name="card_id")
	private Card card;
	@OneToOne
	@JoinColumn(name="game_id")
	private Game game;
	@Column
	@ElementCollection(targetClass=PrizeTypes.class)
	private Set<PrizeTypes> wins;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Card getCard() {
		return card;
	}
	public void setCard(Card card) {
		this.card = card;
	}
	public Game getGame() {
		return game;
	}
	public void setGame(Game game) {
		this.game = game;
	}
	public Set<PrizeTypes> getWins() {
		return wins;
	}
	public void setWins(Set<PrizeTypes> wins) {
		this.wins = wins;
	}
	
}
