package com.dbs.entity.bingo;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class Card {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	@OneToOne
	@JoinColumn(name="user_id")
	private User user;
	@OneToOne
	@JoinColumn(name="game_id")
	private Game game;
	@Column
	@ElementCollection(targetClass=Integer.class)
	private Set<Integer> row1;
	@Column
	@ElementCollection(targetClass=Integer.class)
	private Set<Integer> row2;
	@Column
	@ElementCollection(targetClass=Integer.class)
	private Set<Integer> row3;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public Game getGame() {
		return game;
	}
	public void setGame(Game game) {
		this.game = game;
	}
	public Set<Integer> getRow1() {
		return row1;
	}
	public void setRow1(Set<Integer> row1) {
		this.row1 = row1;
	}
	public Set<Integer> getRow2() {
		return row2;
	}
	public void setRow2(Set<Integer> row2) {
		this.row2 = row2;
	}
	public Set<Integer> getRow3() {
		return row3;
	}
	public void setRow3(Set<Integer> row3) {
		this.row3 = row3;
	}
	
}
