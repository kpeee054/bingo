package com.dbs.entity.bingo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import com.dbs.model.bingo.PrizeClaimStatusTypes;
import com.dbs.model.bingo.PrizeTypes;

@Entity
public class PrizeClaim {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;

	@OneToOne
	@JoinColumn
	private Game game;
	
	@OneToOne
	@JoinColumn
	private User user;
	
	@Column
	private PrizeTypes prizeClaimed;
	
	@Column
	private PrizeClaimStatusTypes status;
	
	@Column
	private Integer latestNumberCalledAtThisClaim;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Game getGame() {
		return game;
	}

	public void setGame(Game game) {
		this.game = game;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public PrizeTypes getPrizeClaimed() {
		return prizeClaimed;
	}

	public void setPrizeClaimed(PrizeTypes prizeClaimed) {
		this.prizeClaimed = prizeClaimed;
	}

	public PrizeClaimStatusTypes getStatus() {
		return status;
	}

	public void setStatus(PrizeClaimStatusTypes status) {
		this.status = status;
	}

	public Integer getLatestNumberCalledAtThisClaim() {
		return latestNumberCalledAtThisClaim;
	}

	public void setLatestNumberCalledAtThisClaim(Integer latestNumberCalledAtThisClaim) {
		this.latestNumberCalledAtThisClaim = latestNumberCalledAtThisClaim;
	}
	
}
