package com.dbs.controller.bingo;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.dbs.entity.bingo.Card;
import com.dbs.entity.bingo.Game;
import com.dbs.entity.bingo.PrizeClaim;
import com.dbs.entity.bingo.PrizeWin;
import com.dbs.entity.bingo.User;
import com.dbs.model.bingo.GameNumber;
import com.dbs.model.bingo.ReturnStatus;
import com.dbs.service.bingo.GameService;
import com.dbs.service.bingo.LoginService;
import com.dbs.service.bingo.UserService;

@RestController
public class ApiController {

	@Autowired
	GameService gameService;

	@Autowired
	UserService userService;

	@Autowired
	LoginService loginService;

	@GetMapping("/login")
	public Long loginUser(@RequestParam("name") String name) {
		return loginService.login(name);
	}

	@GetMapping("/{userId}/logout")
	public ReturnStatus logoutUser(@PathVariable("userId") String userId) {
		return loginService.logout(userId);
	}

	@GetMapping("/startNewGame")
	public Game startNewGame() {
		return gameService.startGame();
	}

	@GetMapping("/getStartedGame")
	public Game getStartedGame() {
		return gameService.fetchStartedGame();
	}

	@GetMapping("/createUsers")
	public List<User> createUsers() {
		return userService.createUsers();
	}

	@GetMapping("/getAllUsers")
	public List<User> getAllUsers() {
		return userService.getAllUsers();
	}

	@GetMapping("/{userId}/joinGame")
	public Game joinGame(@PathVariable("userId") String userId) {
		return gameService.joinGame(userId);
	}

	@GetMapping("/{userId}/newCard")
	public Card getNewCard(@PathVariable("userId") String userId) {
		return gameService.getNewCard(userId);
	}

	@GetMapping("/{userId}/card")
	public Card getExistingCard(@PathVariable("userId") String userId) {
		return gameService.getExistingCard(userId);
	}

	@GetMapping("/{userId}/confirmCard")
	public Card confirmCard(@PathVariable("userId") String userId) {
		return gameService.confirmCard(userId);
	}

	@Autowired
	private SimpMessagingTemplate template;

	@GetMapping("/play/newNumber")
	public GameNumber getNewNumber() {
		GameNumber ret = gameService.getNewNumber();
		this.template.convertAndSend("/topic/ws/newNumber", ret);
		return ret;
	}

	@GetMapping("/play/latestNumber")
	public GameNumber getLatestNumber() {
		return gameService.getLatestNumber();
	}

	@GetMapping("/{userId}/prize/claim")
	public PrizeClaim prizeClaim(@PathVariable("userId") String userId, @RequestParam("prize") String prizeName) {
		return gameService.prizeClaim(userId, prizeName);
	}

	@GetMapping("/endGame")
	public ReturnStatus endGame() {
		return gameService.endGame();
	}

	@GetMapping("/abortGame")
	public ReturnStatus abortGame() {
		return gameService.abortGame();
	}

	@GetMapping("/getPrizeWins")
	public Set<PrizeWin> getWinners() {
		return gameService.getPrizeWins();
	}

	@ExceptionHandler({ Exception.class, RuntimeException.class })
	public ReturnStatus handleException(Exception ex) {
		ex.printStackTrace();
		return new ReturnStatus("-1", ex.getMessage());
	}
}