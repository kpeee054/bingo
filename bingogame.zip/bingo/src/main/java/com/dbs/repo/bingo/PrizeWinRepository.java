package com.dbs.repo.bingo;

import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.dbs.entity.bingo.Game;
import com.dbs.entity.bingo.PrizeWin;

@Repository
public interface PrizeWinRepository extends JpaRepository<PrizeWin, Long> {
	Set<PrizeWin> findByGame(Game game);
}
