package com.dbs.repo.bingo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.dbs.entity.bingo.Game;
import com.dbs.model.bingo.GameStatusTypes;

@Repository
public interface GameRepository extends JpaRepository<Game, Long> {
	Game findByCurrentState(GameStatusTypes state);
}
